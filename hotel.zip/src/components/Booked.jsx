import React,{useState, useEffect} from 'react';
// import ContextProvider from "./ContextProvider";
const Booked = () => {
    useEffect(()=>{

    })
    return (
        <>
            <div className="Booked-main">
                <div className="con">
                    <h1>Welcome AMit Vegad</h1>
                    <p>You have already booked room.</p>
                    <h3>Your room details are follow</h3>
                    <h3>Hostel NO:10</h3>
                    <h3>Room No: 8</h3>
                </div>
            </div>
        </>
    );
};

export default Booked;