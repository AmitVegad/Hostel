import React, {useState} from 'react';

const Room = () => {
    const [room,setRoom] = useState(null);
    const [floor,setFloor] = useState(null);
    const roomChange = (roomNo) =>{
        localStorage.setItem('roomNo',roomNo);
        setRoom(roomNo);
    }
    const floorChange= (e) =>{
        localStorage.setItem('floor' , e.target.value);
        setFloor(e.target.value);
        
    }
    return (
            <div className="room-main">
            <div>
            <h4>Choose a Floor</h4>
            <select className='sel' onChange={floorChange}>
                <option value="1st Floor">1st Floor</option>
                <option value="2st Floor">2nd Floor</option>
                <option value="3st Floor">3rd Floor</option>
                <option value="4st Floor">4th Floor</option>
                <option value="5st Floor">5th Floor</option>
                <option value="6st Floor">6th Floor</option>
            </select>
            <div className='divbtn'>
                <table className='matrix'>
                    <tr>
                        <td><button className={room === "1" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("1")}}>1</button></td>
                        <td><button className={room === "2" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("2")}}>2</button></td>
                        <td><button className={room === "3" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("3")}}>3</button></td>
                        <td><button className={room === "4" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("4")}}>4</button></td>
                    </tr>
                    <tr>
                        <td><button className={room === "10" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("10")}}>10</button></td>
                        <td></td>
                        <td></td>
                        <td><button className={room === "5" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("5")}}>5</button></td>
                    </tr>
                    <tr>
                        <td><button className={room === "9" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("9")}}>9</button></td>
                        <td><button className={room === "8" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("8")}}>8</button></td>
                        <td><button className={room === "7" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("7")}}>7</button></td>
                        <td><button className={room === "6" ? "btn-room-gray" : "btn-room"} onClick={()=>{roomChange("6")}}>6</button></td>
                    </tr>
                </table>
            </div>
            <button className='bookbtn'>Book a Room</button>
        </div>
        </div>
    );
};

export default Room;